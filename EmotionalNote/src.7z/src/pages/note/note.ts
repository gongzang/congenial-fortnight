import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-note',
  templateUrl: 'note.html'
})
export class NotePage {

  constructor(public navCtrl: NavController) {

  }

}
